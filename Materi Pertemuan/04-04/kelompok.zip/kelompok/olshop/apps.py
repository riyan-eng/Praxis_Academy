from django.apps import AppConfig


class OlshopConfig(AppConfig):
    name = 'olshop'
